#pragma once

/*
 * Copyright (C) 2021 LEIDOS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

/*
 * Originally Developed for ROS1 by the UCLA Mobility Lab, 10/20/2021. 
 *
 * Creator: Xu Han
 * Author: Xu Han, Xin Xia, Zonglin Meng, Jiaqi Ma
 * 
 * 8/15/2022: Ported to ROS2
 */

#include <iostream>

namespace emergency_pullover_strategic
{

  /**
   * \brief Stuct containing the algorithm configuration values for the emergency_pullover_strategic
   */
  struct EmergencyPulloverPluginConfig
  {
    /**
     * 
     * vehicleID (str):           
     *  The default vehicle ID.
     * 
     * lane_change_desired_steps (int): 
     *  Desired strategic planning steps to finish lane change. 
     * 
     * maxCrosstrackError (float, m):    
     *  Maximum threshold value of cross track difference 
     *  when determining vehicle lane positions.
     * 
     * time_step (float, s):            
     *  Time length of each strategic control step (default 15s).
     * 
     * lane_change_speed_adjustment (float): 
     *  A float ratio (0~1) to adjust vehicle current speed
     *  when emergency vehicle is detected.
     * 
     * maxLaneChangeDist (float, m):
     *  Maximum maneuver plan distance for lane change.
     * 
     * stopping_deceleration (float, m/s^2):
     *  The desired deceleration when performing emergency stopping.
     * 
     * lane_change_recheck_time (float, s):
     *  A brief time for host to follow current lane at a reduced speed 
     *  before check again for lane change to the right.
     * 
     */ 

    bool detecting_emergency_in_front   = false; // bool indicator left for front emergency vehicle detection
    std::string vehicleID               = "default_id";
    int lane_change_desired_steps       = 1;    
    double maxCrosstrackError           = 2.0;  // m
    double time_step                    = 15.0; // s
    double lane_change_speed_adjustment = 0.7; 
    double maxLaneChangeDist            = 22.0; //m
    double stopping_deceleration        = 2.5;  // m/s^2
    double lane_change_recheck_time     = 1.5;  //s


    friend std::ostream& operator<<(std::ostream& output, const EmergencyPulloverPluginConfig& c)
    {
      output << "EmergencyPulloverPluginConfig { " << std::endl
            << "detecting_emergency_in_front: " << c.detecting_emergency_in_front << std::endl
            << "vehicleID: " << c.vehicleID << std::endl
            << "lane_change_desired_steps: " << c.lane_change_desired_steps << std::endl
            << "maxCrosstrackError: " << c.maxCrosstrackError << std::endl
            << "time_step: " << c.time_step << std::endl
            << "lane_change_speed_adjustment: " << c.lane_change_speed_adjustment << std::endl
            << "maxLaneChangeDist: " << c.maxLaneChangeDist << std::endl
            << "stopping_deceleration: " << c.stopping_deceleration << std::endl
            << "lane_change_recheck_time: " << c.lane_change_recheck_time << std::endl
            << "}" << std::endl; 
      return output;
    }
  };

}//platoon_strategic_ihp
