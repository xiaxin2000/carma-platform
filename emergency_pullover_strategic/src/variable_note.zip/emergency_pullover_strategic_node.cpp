/*
 * Copyright (C) 2022 LEIDOS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
#include "emergency_pullover_strategic/emergency_pullover_strategic_node.h"
#include "emergency_pullover_strategic/emergency_pullover_config.h"
#include <carma_ros2_utils/timers/TimerFactory.hpp>
#include <carma_ros2_utils/timers/ROSTimerFactory.hpp>

namespace emergency_pullover_strategic
{
  namespace std_ph = std::placeholders;

  Node::Node(const rclcpp::NodeOptions &options)
      : carma_guidance_plugins::StrategicPlugin(options)
  {
    // Create initial config
    config_ = EmergencyPulloverPluginConfig();

    // Declare parameters
    /**
     * 
     * vehicleID (str):           
     *  The default vehicle ID.
     * 
     * lane_change_desired_steps (int): 
     *  Desired strategic planning steps to finish lane change. 
     * 
     * maxCrosstrackError (float, m):    
     *  Maximum threshold value of cross track difference 
     *  when determining vehicle lane positions.
     * 
     * time_step (float, s):            
     *  Time length of each strategic control step (default 15s).
     * 
     * lane_change_speed_adjustment (float): 
     *  A float ratio (0~1) to adjust vehicle current speed
     *  when emergency vehicle is detected.
     * 
     * maxLaneChangeDist (float, m):
     *  Maximum maneuver plan distance for lane change.
     * 
     * stopping_deceleration (float, m/s^2):
     *  The desired deceleration when performing emergency stopping.
     * 
     * lane_change_recheck_time (float, s):
     *  A brief time for host to follow current lane at a reduced speed 
     *  before check again for lane change to the right.
     * 
     */ 
    
    declare_parameter<bool>("detecting_emergency_in_front", config_.detecting_emergency_in_front);

    declare_parameter<std::string>("vehicle_id", config_.vehicleID);

    declare_parameter<int>("lane_change_desired_steps", config_.lane_change_desired_steps);

    declare_parameter<double>("time_step", config_.time_step);
    declare_parameter<double>("lane_change_speed_adjustment", config_.lane_change_speed_adjustment);
    declare_parameter<double>("maxLaneChangeDist", config_.maxLaneChangeDist);
    declare_parameter<double>("stopping_deceleration", config_.stopping_deceleration);
    declare_parameter<double>("lane_change_recheck_time", config_.lane_change_recheck_time);

  }

  rcl_interfaces::msg::SetParametersResult Node::parameter_update_callback(const std::vector<rclcpp::Parameter> &parameters)
  {

    auto error = update_params<bool>({
      {"detecting_emergency_in_front", config_.detecting_emergency_in_front}
    }, parameters);
    
    auto error2 = update_params<int>({
      {"lane_change_desired_steps", config_.lane_change_desired_steps}
    }, parameters);

    auto error3 = update_params<double>({
      {"time_step", config_.time_step},
      {"lane_change_speed_adjustment", config_.lane_change_speed_adjustment},
      {"maxLaneChangeDist", config_.maxLaneChangeDist},
      {"stopping_deceleration", config_.stopping_deceleration},
      {"lane_change_recheck_time", config_.lane_change_recheck_time}
      // vehicle_length and id excluded since they should not be updated at runtime
    }, parameters);


    rcl_interfaces::msg::SetParametersResult result;

    result.successful = !error && !error2 && !error3;

    if (result.successful && worker_)
    {
      worker_->setConfig(config_);
    }

    return result;
  }

  carma_ros2_utils::CallbackReturn Node::on_configure_plugin()
  {
    // Reset config
    config_ = EmergencyPulloverPluginConfig();

    // Load parameters
    get_parameter<bool>("detecting_emergency_in_front", config_.detecting_emergency_in_front);

    get_parameter<std::string>("vehicle_id", config_.vehicleID);

    get_parameter<int>("lane_change_desired_steps", config_.lane_change_desired_steps);

    get_parameter<double>("time_step", config_.time_step);
    get_parameter<double>("lane_change_speed_adjustment", config_.lane_change_speed_adjustment);
    get_parameter<double>("maxLaneChangeDist", config_.maxLaneChangeDist);
    get_parameter<double>("stopping_deceleration", config_.stopping_deceleration);
    get_parameter<double>("lane_change_recheck_time", config_.lane_change_recheck_time);

    // Register runtime parameter update callback
    add_on_set_parameters_callback(std::bind(&Node::parameter_update_callback, this, std_ph::_1));

    // no publishers to be setup

    // Build worker
    worker_ = std::make_shared<EmergencyPulloverStrategicPlugin>(get_world_model(), 
                                                                 config_,
                                                                 std::make_shared<carma_ros2_utils::timers::ROSTimerFactory>(shared_from_this()));
    // --------------------------------------------------------------------------------------------------------------------------------------------------------
    /**
     * todo:
     * Need to specify which list contains "emergency object vehicle" then subscribe to corresponding msg.
     * 
     */ 

    // Setup subscribers
    // subscribe to external object detection results (note: the topic name was following "roadway object" and "motion computation" node. May need to change here to "external object list")
    external_obj_sub = create_subscription<carma_perception_msgs::msg::ExternalObjectList>("external_objects", 10,
                                                        std::bind(&EmergencyPulloverStrategicPlugin::external_objects_cb, worker_.get(), std_ph::_1));
    // subscribe to external object detection results 
    roadway_obstacles_sub = create_subscription<carma_perception_msgs::msg::RoadwayObstacleList>("roadway_obstacles", 10,
                                                        std::bind(&EmergencyPulloverStrategicPlugin::roadway_obstacles_cb, worker_.get(), std_ph::_1));

    // --------------------------------------------------------------------------------------------------------------------------------------------------------

    // subscribe to current pose
    current_pose_sub = create_subscription<geometry_msgs::msg::PoseStamped>("current_pose", 10,
                                                              std::bind(&EmergencyPulloverStrategicPlugin::pose_cb, worker_.get(), std_ph::_1));
    // subscribe to current twist command
    current_twist_sub = create_subscription<geometry_msgs::msg::TwistStamped>("current_velocity", 10,
                                                              std::bind(&EmergencyPulloverStrategicPlugin::twist_cb, worker_.get(), std_ph::_1));
    // subscribe to current command
    cmd_sub = create_subscription<geometry_msgs::msg::TwistStamped>("twist_raw", 10,
                                                              std::bind(&EmergencyPulloverStrategicPlugin::cmd_cb, worker_.get(), std_ph::_1));
    // subscribe to current geo 
    georeference_sub = create_subscription<std_msgs::msg::String>("georeference", 10,
                                                              std::bind(&EmergencyPulloverStrategicPlugin::georeference_cb, worker_.get(), std_ph::_1));
    // loop timer
    loop_timer_ = create_timer(get_clock(),
                               std::chrono::milliseconds(100), // 10 Hz frequency
                               std::bind(&EmergencyPulloverStrategicPlugin::onSpin, worker_.get()));

    // Return success if everything initialized successfully
    return CallbackReturn::SUCCESS;
  }

  carma_ros2_utils::CallbackReturn Node::on_cleanup_plugin()
  {
    // Ensure subscribers are disconnected incase cleanup is called, we don't want to keep driving the worker
    current_pose_sub.reset();
    current_twist_sub.reset();
    cmd_sub.reset();
    georeference_sub.reset();
    worker_.reset();

    return CallbackReturn::SUCCESS;
  }


  void Node::plan_maneuvers_callback(
    std::shared_ptr<rmw_request_id_t>, 
    carma_planning_msgs::srv::PlanManeuvers::Request::SharedPtr req, 
    carma_planning_msgs::srv::PlanManeuvers::Response::SharedPtr resp)
  {
    if (worker_)
      worker_->plan_maneuver_cb(*req, *resp);
  }

  bool Node::get_availability() {
    return true;
  }

  std::string Node::get_version_id() {
    return "v4.0";
  }

} // emergency_pullover_strategic

#include "rclcpp_components/register_node_macro.hpp"

// Register the component with class_loader
RCLCPP_COMPONENTS_REGISTER_NODE(emergency_pullover_strategic::Node)
