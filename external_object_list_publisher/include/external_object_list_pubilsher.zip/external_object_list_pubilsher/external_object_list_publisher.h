/*
 * Copyright (C) 2019-2021 LEIDOS.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

/*
 * Developed by the UCLA Mobility Lab, 10/20/2021. 
 *
 * Creator: Xu Han
 * Author: Xu Han, Xin Xia, Zonglin Meng, Jiaqi Ma
 */

#pragma once

#include <gtest/gtest_prod.h>
#include <vector>
#include <math.h>
#include <carma_planning_msgs/msg/trajectory_plan.hpp>
#include <carma_planning_msgs/msg/trajectory_plan_point.hpp>
#include <carma_planning_msgs/msg/plugin.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/format.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/twist_stamped.hpp>
#include <carma_planning_msgs/srv/plan_maneuvers.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>

#include <carma_perception_msgs/msg/external_object_list.hpp>
#include <carma_perception_msgs/msg/external_object.hpp>
#include <carma_perception_msgs/msg/roadway_obstacle_list.hpp>
#include <carma_perception_msgs/msg/roadway_obstacle.hpp>

#include <carma_v2x_msgs/msg/mobility_operation.hpp>
#include <carma_v2x_msgs/msg/mobility_request.hpp>
#include <carma_v2x_msgs/msg/mobility_response.hpp>
#include <carma_v2x_msgs/msg/plan_type.hpp>

#include <carma_wm_ros2/WorldModel.hpp>
#include <lanelet2_core/geometry/Lanelet.h>
#include <lanelet2_core/geometry/BoundingBox.h>
#include <lanelet2_extension/traffic_rules/CarmaUSTrafficRules.h>
#include <lanelet2_extension/regulatory_elements/DigitalMinimumGap.h>
#include "external_object_list_publisher_config.h"
#include <tf2_ros/transform_listener.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <lanelet2_extension/projection/local_frame_projector.h>
#include <std_msgs/msg/string.hpp>
#include <rclcpp/time.hpp>
#include <carma_ros2_utils/timers/TimerFactory.hpp>

namespace external_object_list_publisher
{
    using ExternalObjectListCB = std::function<void(const carma_perception_msgs::msg::ExternalObjectList&)>;


    class ExternalObjectListPublisher
    {
        public: 

            /**
            * \brief Constructor
            * 
            * \param wm Pointer to initalized instance of the carma world model for accessing semantic map data
            * \param config The configuration to be used for this object
            */ 
            ExternalObjectListPublisher(carma_wm::WorldModelConstPtr wm, 
                                        ExternalObjectListPublisherConfig config, 
                                        ExternalObjectListCB external_object_list_publisher,
                                        std::shared_ptr<carma_ros2_utils::timers::TimerFactory> timer_factory);

            /**
            * \brief Function to convert pose from map frame to ecef location
            *
            * \param pose_msg pose message
            *
            * \return mobility operation msg
            */
            carma_v2x_msgs::msg::LocationECEF pose_to_ecef(geometry_msgs::msg::PoseStamped pose_msg);

            /**
             * \brief UCLA Update the private variable pose_ecef_point_
             */
            void setHostECEF(carma_v2x_msgs::msg::LocationECEF pose_ecef_point);

            /**
            * \brief Callback for the georeference
            * 
            * \param msg Latest georeference
            */
            void georeference_cb(const std_msgs::msg::String::UniquePtr msg);

            /**
            * \brief Callback function for current pose
            * 
            * \param msg PoseStamped msg
            */
            void pose_cb(const geometry_msgs::msg::PoseStamped::UniquePtr msg);

            /**
            * \brief Callback for the twist subscriber, which will store latest twist locally
            * 
            * \param msg Latest twist message
            */
            void twist_cb(const geometry_msgs::msg::TwistStamped::UniquePtr msg);

            /**
            * \brief Generate and publish the sythetic message for emergency vehicles
            */
            void publish_external_object_list();

            /**
            * \brief Spin callback function
            */
            bool onSpin();
            
            // public global variable

            // ECEF position of the host vehicle
            carma_v2x_msgs::msg::LocationECEF pose_ecef_point_;

            // Timer factory used to get current time
            std::shared_ptr<carma_ros2_utils::timers::TimerFactory> timer_factory_;

            // Speed below which platooning will not be attempted; non-zero value allows for sensor noise
            const double STOPPED_SPEED = 0.5; // m/s

        private: 

            // private global variables 
            
            // pointer to the actual wm object
            carma_wm::WorldModelConstPtr wm_;

            // local copy of configuration file
            ExternalObjectListPublisherConfig config_;

            // Plugin discovery message
            carma_planning_msgs::msg::Plugin plugin_discovery_msg_;

            // Pointer for map projector
            std::shared_ptr<lanelet::projection::LocalFrameProjector> map_projector_;

            // Current vehicle pose in map
            geometry_msgs::msg::PoseStamped pose_msg_;

            // Current vehicle downtrack distance in route, m
            double current_downtrack_ = 0;

            // Current vehicle crosstrack distance in route, m
            double current_crosstrack_ = 0;

            // Current vehicle measured speed, m/s
            double current_speed_ = 0;


            // Unit Test Accessors
            // FRIEND_TEST(ExternalObjectListPublisher, platoon_info_pub_front);
            // FRIEND_TEST(ExternalObjectListPublisher, is_lanechange_possible);
    };
}
